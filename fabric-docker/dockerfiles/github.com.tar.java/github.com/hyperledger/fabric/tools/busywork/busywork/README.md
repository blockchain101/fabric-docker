# The Go *busywork* package

Currently not much here, other than some infrastructire that allows a
**busywork** application to effectively "throw exceptions" rather than
verbosely/redundantly passing irrecoverable errors up the stack.
