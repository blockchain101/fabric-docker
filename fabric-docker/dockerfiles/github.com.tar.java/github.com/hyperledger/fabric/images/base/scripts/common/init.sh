#!/bin/bash

# Update the box
apt-get -y update
apt-get -y install software-properties-common curl
